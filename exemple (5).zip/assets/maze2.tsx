<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="maze2" tilewidth="32" tileheight="32" tilecount="30" columns="5">
 <image source="maze2.png" width="160" height="192"/>
</tileset>
