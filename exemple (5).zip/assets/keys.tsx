<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="keys" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="keys.png" width="128" height="128"/>
</tileset>
